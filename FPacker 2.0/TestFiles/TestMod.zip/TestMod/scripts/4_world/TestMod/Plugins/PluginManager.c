modded class PluginManager
{	
	void PluginManager()
	{
		GetPBOtestWorld().TestPrint();
	}
}
