static float m_LastTickTimeWorld = GetGame().GetTickTime();
static float m_TickTimeWorld = GetGame().GetTickTime();