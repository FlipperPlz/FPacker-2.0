modded class MissionGameplay
{
    void MissionGameplay()
    {
        Print( "Loaded Client Test Mission" );
		new PBOtestGame();		
		new PBOtestWorld();
		new PBOtestMission();
    }
};