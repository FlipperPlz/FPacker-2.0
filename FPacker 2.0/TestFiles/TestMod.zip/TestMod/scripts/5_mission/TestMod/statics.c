static float m_LastTickTimeMission = GetGame().GetTickTime();
static float m_TickTimeMission = GetGame().GetTickTime();