static float m_LastTickTime = GetGame().GetTickTime();
static float m_TickTime = GetGame().GetTickTime();