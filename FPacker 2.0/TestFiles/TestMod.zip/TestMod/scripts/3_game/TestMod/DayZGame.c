modded class DayZGame
{
	void DayZGame()
	{		
		GetPBOtestGame().TestPrint();
	}
}